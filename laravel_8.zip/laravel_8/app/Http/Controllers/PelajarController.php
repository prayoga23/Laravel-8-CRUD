<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pelajar;

class PelajarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pelajar = Pelajar::all();
        
        return view('index',compact('pelajar'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createpelajar');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $validatedData = $request->validate([
            'nama' => 'required|max:255',
            'kelas' => 'required',
            'alamat' => 'required|max:255'
        ]);
        $show = Pelajar::create($validatedData);
   
        return redirect('/pelajar')->with('success', 'Data Pelajar berhasil di simpan');
    }
}
