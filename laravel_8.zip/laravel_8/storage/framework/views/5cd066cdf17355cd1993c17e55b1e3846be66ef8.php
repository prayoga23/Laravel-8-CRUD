

<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <a class="btn btn-success" href="<?php echo e(URL::to('games/create')); ?>">Add Data Games</a>
  <table class="table table-striped">
    <thead>
        <tr>
          <td>ID</td>
          <td>Nama Game</td>
          <td>Harga</td>
          <td>Action</td>
        </tr>
    </thead>
    <tbody>
          <?php
            $nomer = 1;
            ?>
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($nomer++); ?></td>
            <td><?php echo e($game->name); ?></td>
            <td><?php echo e($game->price); ?></td>
            <td><a href="<?php echo e(route('games.edit', $game->id)); ?>" class="btn btn-primary">Edit</a>
            <td>
              <form action="<?php echo e(route('games.destroy', $game->id)); ?>" method="post">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_8\resources\views/index.blade.php ENDPATH**/ ?>